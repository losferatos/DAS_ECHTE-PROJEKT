import random
arr_short = []
arr_long = []

#load DB
with open("db_short.txt") as file_s:
    data = file_s.read()
    arr_short.append(data + "\n")

with open("db_long.txt") as file_l:
    data = file_l.read()
    arr_long.append(data + "\n")

a = arr_long[0].split("\n")

print(a)
""" #loop
while 1 > 0:
    print("1: gib mir nen kurzen task")
    print("2: gib mir nen langen task")
    print("3: add short task")
    print("4: add long task")

    frage = input("Zahl der Auswahl eingebe: ")

    if frage == "1": print(random.choice(arr_short))
    elif frage == "2": print(random.choice(arr_long))
    elif frage == "3": 
        temp = input("kurzen task hinzufügen: \n")
        arr_short.append(temp)
        #in db speichern
    elif frage == "4": 
        temp = input("langen task hinzufügen: \n")
        arr_long.append(temp)
        #in db speichern """