def solution(string, ending):
    if len(ending) == 0: return True
    return string[-len(ending):] == ending



check1 = solution('abcde', '')
print(check1)

