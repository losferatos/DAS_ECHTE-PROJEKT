def find_word(board, word):
    pass


testBoard = [ 
    ["I","L","A","W"],
    ["B","N","G","E"],
    ["I","U","A","O"],
    ["A","S","R","L"] 
    ]


check = find_word(testBoard, "bingo")
print(check)