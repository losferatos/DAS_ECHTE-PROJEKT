def row_sum_odd_numbers(n):
    res = []
    temp = []
    counter = 1
    result = 0

    for i in range(1,999):
        if i % 2 != 0:
            temp.append(i)
            
            if len(temp) == counter:
                res.append(temp)
                counter += 1
                          
                if counter == n + 1:
                    for number in temp:
                        result += number
                temp.clear()

    return result

check1 = row_sum_odd_numbers(13)
print(check1)


