#https://www.codewars.com/kata/55fd2d567d94ac3bc9000064/train/python

def row_sum_odd_numbers(n):
    nums = [a for a in range(1,12) if a % 2 != 0]
    arr = []

    
            
    
        
    return nums

check = row_sum_odd_numbers(13)
print(check)